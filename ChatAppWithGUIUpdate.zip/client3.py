import socketio
import tkinter as tk
from tkinter import simpledialog, scrolledtext, messagebox

# Socket.IO client
sio = socketio.Client()
username = ""

# GUI setup. This will setup the message box that will prompt the user for a username and allow them to message other users.
root = tk.Tk()
root.withdraw()
username = simpledialog.askstring("Username", "Enter your username:", parent=root)
if not username:
    messagebox.showerror("Error", "Username cannot be empty.")
    exit()
root.deiconify()
root.title(f"Chat - {username}")
root.geometry("500x400")

ChatBox = scrolledtext.ScrolledText(root, state='disabled')
ChatBox.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

entry_field = tk.Entry(root)
entry_field.pack(padx=10, pady=(0, 10), fill=tk.X)

def display_message(message):
    ChatBox.config(state='normal')
    ChatBox.insert(tk.END, message + '\n')
    ChatBox.yview(tk.END)
    ChatBox.config(state='disabled')

def send_message(event=None):
    message = entry_field.get()
    if message:
        if message.lower() == "/quit":
            sio.disconnect()
            root.quit()
        else:
            sio.send(f"{username}: {message}")
        entry_field.delete(0, tk.END)

entry_field.bind("<Return>", send_message)

send_button = tk.Button(root, text="Send", command=send_message)
send_button.pack(padx=10, pady=(0, 10))

@sio.on('message')
def on_message(data):
    display_message(data)

try:
    sio.connect('http://127.0.0.1:3000')
    sio.send(f"{username} has joined the chat.")
except Exception as e:
    messagebox.showerror("Connection Error", f"Unable to connect to server: {e}")
    exit()

root.mainloop()
